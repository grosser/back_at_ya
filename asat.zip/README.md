:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Agent Satisfaction App

## Description:

App that let's agents rate users.

An app which uses the below endpoints:

* /api/v2/users/{{user_id}}/.json

## App location:

* Ticket sidebar

## Set-up/installation instructions:

Download asat.zip, install it, then open a ticket.
